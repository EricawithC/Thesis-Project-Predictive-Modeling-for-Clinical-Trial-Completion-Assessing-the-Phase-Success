## 1. import 
## 2. input & hyperparameter
## 3. pretrain 
## 4. 'dataloader, model build, train, inference'
################################################


## 1. import 
 
import torch, os, sys
torch.manual_seed(0) 
sys.path.append('.')
from HINT.dataloader_enrollment import csv_three_feature_2_dataloader, generate_admet_dataloader_lst, csv_three_feature_2_complete_dataloader
from HINT.molecule_encode import MPNN 
from HINT.icdcode_encode import GRAM, build_icdcode2ancestor_dict
from HINT.protocol_encode import Protocol_Embedding
from HINT.model_experiment_enrollment import Interaction, HINT_nograph, HINTModel,Highway,GCN,GraphConvolution
from HINT.model_experiment_enrollment import ADMET

torch.cuda.empty_cache()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if not os.path.exists("figure"):
	os.makedirs("figure")


## 2. data
base_name = 'phase_I' 
# base_name = "toy" 
datafolder = "data"

#train_file = 'data/phase_I_train.csv'
#valid_file = 'data/phase_I_valid.csv'
#test_file = 'data/phase_I_test.csv'

train_file = os.path.join(datafolder, base_name + '_train.csv')
valid_file = os.path.join(datafolder, base_name + '_valid.csv')
test_file = os.path.join(datafolder, base_name + '_test.csv')

print(base_name)

print(len(train_file))
print(len(valid_file))
print(len(test_file))


## 4. dataloader, model build, train, inference
train_loader = csv_three_feature_2_dataloader(train_file, shuffle=True, batch_size=32) 
valid_loader = csv_three_feature_2_dataloader(valid_file, shuffle=False, batch_size=32) 
test_loader = csv_three_feature_2_dataloader(test_file, shuffle=False, batch_size=32)
complete_dataloader = csv_three_feature_2_complete_dataloader(train_file,shuffle=False, batch_size=32) 

print(len(train_loader))
print(len(valid_loader))
print(len(test_loader))

icdcode2ancestor_dict = build_icdcode2ancestor_dict()
gram_model = GRAM(embedding_dim = 50, icdcode2ancestor = icdcode2ancestor_dict, device = device)
protocol_model = Protocol_Embedding(output_dim = 50, highway_num=3, device = device)


hint_model_path = "save_model/" + base_name + ".ckpt"
if not os.path.exists(hint_model_path):

	## 3. pretrain 
	mpnn_model = MPNN(mpnn_hidden_size = 50, mpnn_depth=3, device = device)
	admet_model_path = "save_model/admet_model.ckpt"
	if not os.path.exists(admet_model_path):
		admet_dataloader_lst = generate_admet_dataloader_lst(batch_size=32)
		admet_trainloader_lst = [i[0] for i in admet_dataloader_lst]
		admet_testloader_lst = [i[1] for i in admet_dataloader_lst]
		admet_model = ADMET(molecule_encoder = mpnn_model, 
							highway_num=2, 
							device = device, 
							epoch=3, 
							lr=5e-4, 
							weight_decay=0, 
							save_name = 'admet_')
		admet_model.train(admet_trainloader_lst, admet_testloader_lst)
		torch.save(admet_model, admet_model_path)
		print('OK ADMET')
	else:
		admet_model = torch.load(admet_model_path)
		admet_model = admet_model.to(device)
		admet_model.set_device(device)
		print('ko ADMET')


	model = HINTModel(#molecule_encoder = mpnn_model, 
			 disease_encoder = gram_model, 
			 protocol_encoder = protocol_model,
			 device = device, 
			 global_embed_size = 50, 
			 highway_num_layer = 2,
			 prefix_name = base_name, 
			 gnn_hidden_size = 50,  
			 epoch = 5,
			 lr = 1e-3, 
			 weight_decay = 0, 
			)
	#model.init_pretrain(admet_model)
	model.learn(train_loader, valid_loader, test_loader)
	model.generate_predict(test_loader)
	torch.save(model, hint_model_path)
	print("OK MODEL")
else:
	model = torch.load(hint_model_path,weights_only=False)
	model.generate_predict(test_loader)
	torch.save(model, hint_model_path)
	print ("KO")















