import torch
import torch.nn as nn
import torch.nn.functional as F
from copy import deepcopy 
from torch.autograd import Variable
from torch.utils import data
from torch.utils.data import SequentialSampler
import matplotlib.pyplot as plt
import numpy as np 
sigmoid = torch.nn.Sigmoid() 
torch.manual_seed(0)
import sys
import math
import numpy as np
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module 
np.random.seed(1)
import os
sys.path.append(os.path.abspath(".."))
from tqdm import tqdm
import logging
logging.basicConfig(level=logging.INFO)  
import networkx as nx
import shap
from tqdm import tqdm

"The following codes aims at analysing the attention matrix results used for the final model's performance"



"""
Step 1
"""

class ADMET(nn.Sequential):
    def __init__(self, molecule_encoder, highway_num, device, epoch, lr, weight_decay, save_name):
        """
        Initialize the ADMET model with specified parameters.

        Parameters:
        - molecule_encoder: the MPNN-based molecule encoder for generating embeddings
        - highway_num: int, the number of layers in each highway network
        - device: torch.device, the device to run computations on
        - epoch: int, the number of training epochs
        - lr: float, the learning rate
        - weight_decay: float, the weight decay for the optimizer
        - save_name: str, the name for saving the model
        """
        super(ADMET, self).__init__()
        self.molecule_encoder = molecule_encoder
        self.embedding_size = self.molecule_encoder.embedding_size
        self.highway_num = highway_num

        # Define a list of highway networks, one for each output task
        self.highway_nn_lst = nn.ModuleList([
            Highway(size=self.embedding_size, num_layers=self.highway_num) for _ in range(5)
        ])

        # Define a list of fully connected layers, one for each output task
        self.fc_output_lst = nn.ModuleList([nn.Linear(self.embedding_size, 1) for _ in range(5)])

        # Set activation function and loss function
        self.f = F.relu
        self.loss = nn.BCEWithLogitsLoss()  # Binary cross-entropy loss with logits

        # Set training parameters
        self.epoch = epoch
        self.lr = lr
        self.weight_decay = weight_decay
        self.save_name = save_name

        # Set the computation device and move model to the device
        self.device = device
        self = self.to(device)

    def set_device(self, device):
        """
        Update the device for computations and set the molecule encoder’s device.
        """
        self.device = device
        self.molecule_encoder.set_device(device)

    def forward_smiles_lst_embedding(self, smiles_lst, idx):
        """
        Generate embeddings for a list of SMILES strings using the molecule encoder.

        Parameters:
        - smiles_lst: list of SMILES strings
        - idx: int, the index of the specific highway network to use

        Returns:
        - torch.Tensor: the output from the highway network for the given index
        """
        embed_all = self.molecule_encoder.forward_smiles_lst(smiles_lst)
        output = self.highway_nn_lst[idx](embed_all)
        return output

    def forward_embedding_to_pred(self, embeded, idx):
        """
        Pass embeddings through a fully connected layer to generate predictions.

        Parameters:
        - embeded: torch.Tensor, molecule embeddings
        - idx: int, the index of the output layer

        Returns:
        - torch.Tensor: predicted value for each molecule
        """
        return self.fc_output_lst[idx](embeded)

    def forward_smiles_lst_pred(self, smiles_lst, idx):
        """
        Generate predictions for a list of SMILES strings.

        Parameters:
        - smiles_lst: list of SMILES strings
        - idx: int, index of the prediction task

        Returns:
        - torch.Tensor: predictions for each SMILES string in the list
        """
        embeded = self.forward_smiles_lst_embedding(smiles_lst, idx)
        fc_output = self.forward_embedding_to_pred(embeded, idx)
        return fc_output

    def test(self, dataloader_lst, return_loss=True):
        """
        Evaluate the model on a test dataset.

        Parameters:
        - dataloader_lst: list of DataLoaders, one for each task
        - return_loss: bool, whether to return the loss

        Returns:
        - float: mean loss over all tasks
        """
        loss_lst = []
        for idx in range(1):  # Loop over tasks
            single_loss_lst = []
            for smiles_lst, label_vec in dataloader_lst[idx]:
                output = self.forward_smiles_lst_pred(smiles_lst, idx).view(-1)
                loss = self.loss(output, label_vec.to(self.device).float())
                single_loss_lst.append(loss.item())
            loss_lst.append(np.mean(single_loss_lst))
        return np.mean(loss_lst)

    def train(self, train_loader_lst, valid_loader_lst):
        """
        Train the model over multiple epochs and validate after each epoch.

        Parameters:
        - train_loader_lst: list of DataLoaders for training, one for each task
        - valid_loader_lst: list of DataLoaders for validation, one for each task
        """
        opt = torch.optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        train_loss_record = []

        # Initial validation loss
        valid_loss = self.test(valid_loader_lst, return_loss=True)
        valid_loss_record = [valid_loss]
        best_valid_loss = valid_loss
        best_model = deepcopy(self)

        # Train over specified number of epochs
        for ep in tqdm(range(self.epoch)):
            data_iterator_lst = [iter(train_loader_lst[idx]) for idx in range(5)]
            try:
                while True:
                    # Loop over each task (here, using only the first task as an example)
                    for idx in range(1):
                        smiles_lst, label_vec = next(data_iterator_lst[idx])
                        output = self.forward_smiles_lst_pred(smiles_lst, idx).view(-1)
                        loss = self.loss(output, label_vec.float())

                        # Backpropagation and optimization step
                        opt.zero_grad()
                        loss.backward()
                        opt.step()
            except:
                pass

            # Validate the model and record validation loss
            valid_loss = self.test(valid_loader_lst, return_loss=True)
            valid_loss_record.append(valid_loss)

            # Save the model with the best validation loss
            if valid_loss < best_valid_loss:
                best_valid_loss = valid_loss
                best_model = deepcopy(self)

        # Restore the best model after training
        self = deepcopy(best_model)


"""
Step 2
La GraphConvolution implementa lo strato convoluzionale. Crea la formula: H(l) = RELU(B(l) + (V . A)(H(l-1)W(l)))
Nel dettaglio: 
input: H(l-1), ossia gli embeddings, ossia feature dei nodi 
weight: W(l)
adj: A, ossia adjacent matrix 
bias: B(l), ossia il bias 
module: layer di una rete neurale

        support = torch.mm(input, self.weight)  # H^(l-1) * W^(l)
        output = torch.spmm(adj, support)      # A * (H^(l-1) * W^(l))
        return output + self.bias  # A * (H^(l-1) * W^(l)) + B

"""
in_features = 5
out_features = 3 


class GraphConvolution(Module):

    def __init__(self, in_features, out_features, bias=True, init='uniform'): #Metodo di inizializzazione dei pesi
        super(GraphConvolution, self).__init__()
        self.in_features = in_features  #Numero di feature di input per ogni nodo.
        self.out_features = out_features #Numero di feature di output per ogni nodo
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))

        """
        DEFINIZIONE PESI E BIAS
        """ 

        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features)) #Se bias=True, si definisce un vettore di bias di dimensione (out_features).
        #else:
            #self.register_parameter('bias', None)

        #Diverse strategie di inizializzazione: 'uniform', 'xavier', 'kaiming'.
        if init == 'uniform':
            print("| Uniform Initialization")
            self.reset_parameters_uniform()

    def reset_parameters_uniform(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)


        """
        Creazione del GCN base 
        """

    def forward(self, input, adj):
        support = torch.mm(input, self.weight) #Calcola il prodotto tra feature dei nodi e i pesi.
        output = torch.spmm(adj, support) #Propaga l'informazione attraverso il grafo usando la matrice di adiacenza
        if self.bias is not None: #Se il bias è presente, lo somma al risultato.
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

"""
Step 3
La tua implementazione include uno strato di attenzione, GraphAttention, che modifica dinamicamente l'importanza 
delle connessioni tra nodi. Questo corrisponde alla parte 𝑉 ⊙ 𝐴 nella formula.
"""

class GraphAttention(nn.Module):
    """
    Simple GAT layer, similar to https://arxiv.org/abs/1710.10903

    self.W: Matrice di pesi W inizializzata con Xavier Normal
    self.a1 e self.a2: Vettori di attenzione a1 e a2 usati per calcolare i punteggi di attenzione.
    self.leakyrelu: Funzione di attivazione LeakyReLU con parametro alpha. 


    Punteggi di attenzione:

    𝑒𝑖𝑗=LeakyReLU(𝑎1⊤ℎ𝑖 + 𝑎2⊤ℎ𝑗), ossia somma di vettori di attenzione attivati da funzione di LeakyReLU

    Mascheramento e normalizzazione:
    𝛼𝑖𝑗=softmax (𝑒𝑖𝑗 * adjij), ossia normalizzazione di e
    """
    
    in_features = 5
    out_features = 3
    dropout = 0.6
    nheads=4, 
    alpha=0.2
    

    def __init__(self, in_features, out_features, dropout, alpha, concat=True):
        super(GraphAttention, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat

        self.W = nn.Parameter(nn.init.xavier_normal_(torch.Tensor(in_features, out_features).type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor), gain=np.sqrt(2.0)), requires_grad=True)
        self.a1 = nn.Parameter(nn.init.xavier_normal_(torch.Tensor(out_features, 1).type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor), gain=np.sqrt(2.0)), requires_grad=True)
        self.a2 = nn.Parameter(nn.init.xavier_normal_(torch.Tensor(out_features, 1).type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor), gain=np.sqrt(2.0)), requires_grad=True)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, input, adj):
        h = torch.mm(input, self.W)  ## H^(l-1) W^(l) -> Calcolo della rappresentazione lineare
        N = h.size()[0]

        f_1 = torch.matmul(h, self.a1) #Calcolo dei punteggi di attenzione grezzi
        f_2 = torch.matmul(h, self.a2) #Calcolo dei punteggi di attenzione grezzi
        e = self.leakyrelu(f_1 + f_2.transpose(0,1))

        zero_vec = -9e15*torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        attention = F.softmax(attention, dim=1)     #Mascheramento e normalizzazione dei punteggi di attenzione
        attention = F.dropout(attention, self.dropout, training=self.training)      #Mascheramento e normalizzazione dei punteggi di attenzione
        h_prime = torch.matmul(attention, h)

        if self.concat:
            return F.elu(h_prime)
        else:
            return h_prime

    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'


"""
Step 4: 
La classe Highway implementa un Highway Network, un'architettura che combina trasformazioni lineari e non lineari con un meccanismo di gating per 
migliorare il flusso di gradiente in modelli profondi. Questo tipo di rete è particolarmente utile in modelli dove molteplici trasformazioni possono 
portare alla degradazione delle prestazioni (problemi di gradiente vanishing/exploding).

La funzione forward applica le trasformazioni lineari, non lineari e il gating per ogni layer del Highway Network.

"""
num_layers = 2 

class Highway(nn.Module):  #da spiegare 
    def __init__(self, size, num_layers):
        super(Highway, self).__init__()
        self.num_layers = num_layers
        self.nonlinear = nn.ModuleList([nn.Linear(size, size) for _ in range(num_layers)])
        self.linear = nn.ModuleList([nn.Linear(size, size) for _ in range(num_layers)])
        self.gate = nn.ModuleList([nn.Linear(size, size) for _ in range(num_layers)])
        self.f = F.relu

    def forward(self, x):
        for layer in range(self.num_layers):
            gate = torch.sigmoid(self.gate[layer](x))
            nonlinear = self.f(self.nonlinear[layer](x))
            linear = self.linear[layer](x)
            x = gate * nonlinear + (1 - gate) * linear
        return x

"""
Step 5:
        Creazione del GNC
        le informazioni dei nodi (features iniziali 𝐻(0) e la struttura del grafo (matrice di adiacenza A) sono passate agli strati di convoluzione (GCN o GAT).
            x : matrice delle feature iniziali dei nodi
            adj: matrice di adiacenza A 
            gc1, gc2: convoluzione del grafico, che calcola la formula fornita

            GraphConvolution = A * (H^(l-1) * W^(l)) + B 
            F.relu(self.gc1(x, adj) corrisponde a RELU (B + A * (H^(l-1) * W^(l)))
    
"""
 

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, init):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid, init=init)  #convoluzione del grafo 
        self.gc2 = GraphConvolution(nhid, nclass, init=init) #convoluzione del grafo
        self.dropout = dropout

    def bottleneck(self, path1, path2, path3, adj, in_x):
        return F.relu(path3(F.relu(path2(F.relu(path1(in_x, adj)), adj)), adj))

    def forward(self, x, adj):
        x = F.dropout(F.relu(self.gc1(x, adj)), self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x 

gnn = GCN(nfeat = 20,nhid = 30,nclass = 1,dropout = 0.6,init = 'uniform')
"""
Step 6:
    La classe GAT implementa un modello Graph Attention Network (GAT), composto da più strati di attenzione su grafi (GraphAttention). 
    Questo modello utilizza il meccanismo di multi-head attention per aggregare le feature dei nodi, mantenendo informazioni strutturali del grafo
    GAT utilizza GraphAttention come blocco di costruzione per implementare il meccanismo di attenzione multi-head. 

    Multi-Head-Attention: GAT combina i risultati di più GraphAttention concatenandoli. 

    - GraphAttention implementa il calcolo di 𝑉⊙𝐴 e l'aggregazione dei nodi (alphaij hj)
    - GAT utilizza questa logica per costruire una rete multi-head e produrre l'output finale.

    self.attentions: crea nheads strati di GraphAttention in parallelo. Ogni strato calcola un set indipendente di embedding usando attenzione sui vicini.
    self.out_att: Combina gli embedding prodotti dalle nheads teste del livello precedente.

        Ogni testa di attenzione (GraphAttention) elabora l'input X e la matrice di adiacenza adj: H(head) = GraphAttention (X,adj)

"""
drop_out = 0.6
nfeat = 20
nhid = 30
nclass = 1
dropout = 0.6
alpha = 0.2
nheads = 4 

class GAT(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, alpha, nheads):
        super(GAT, self).__init__()
        self.dropout = dropout

        self.attentions = [GraphAttention(nfeat, nhid, dropout=dropout, alpha=alpha, concat=True) for _ in range(nheads)] #diverse istanze di GraphAttention 
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)

        self.out_att = GraphAttention(nhid * nheads, nclass, dropout=dropout, alpha=alpha, concat=False)

    def forward(self, x, adj):
        x = F.dropout(x, self.dropout, training=self.training)  #Viene applicato il dropout sull'input iniziale x prima e dopo aver calcolato l'attenzione
        x = torch.cat([att(x, adj) for att in self.attentions], dim=1) #vengono calcolate le attenzioni per ciascuna delle teste. Ogni testa produce un vettore di embedding, che viene poi concatenato.
        x = F.dropout(x, self.dropout, training=self.training) #La concatenazione dei risultati di tutte le teste di attenzione viene successivamente elaborata dal layer finale di attenzione (out_att).
        x = F.elu(self.out_att(x, adj)) #Dopo aver ottenuto l'output finale dell'attenzione, viene applicata una funzione di attivazione 
        return F.log_softmax(x, dim=1)


if __name__ == "__main__":
    gnn = GCN(
            nfeat = 20,
            nhid = 30,
            nclass = 1,
            dropout = 0.6,
            init = 'uniform') 
    

from sklearn.metrics import roc_auc_score, f1_score, average_precision_score, precision_score, recall_score, accuracy_score
import matplotlib.pyplot as plt
from copy import deepcopy 
import numpy as np 
from tqdm import tqdm 
import torch 
torch.manual_seed(0)
from torch import nn 
from torch.autograd import Variable
import torch.nn.functional as F
from functools import reduce 
import pickle

"""
Step 7
input: 
criteria_lst
smiles_lst2
icdcode_lst3

- Ogni tipo di dato viene passato a encoder separati che producono embedding rappresentativi
- Gli embedding vengono concatenati e trasformati in una rappresentazione globale tramite un meccanismo di gating (Highway) e strati fully connected.

output: 
Una singola previsione binaria per ciascun campione (es. probabilità di successo del trial clinico)
"""


class Interaction(nn.Sequential):
    """
    Produzione embedding
    """
    def __init__(self, molecule_encoder, disease_encoder, protocol_encoder,
                 device, global_embed_size, highway_num_layer,
                 prefix_name, epoch=20, lr=3e-4, weight_decay=0):
        super(Interaction, self).__init__()
        self.molecule_encoder = molecule_encoder
        self.disease_encoder = disease_encoder
        self.protocol_encoder = protocol_encoder
        self.global_embed_size = global_embed_size
        self.highway_num_layer = highway_num_layer
        self.feature_dim = (
            self.molecule_encoder.embedding_size
            + self.disease_encoder.embedding_size
            + self.protocol_encoder.embedding_size
            + self.global_embed_size
        )
        self.epoch = epoch
        self.lr = lr
        self.weight_decay = weight_decay
        self.save_name = prefix_name + '_interaction'
        self.debug = False

        self.f = F.relu
        self.loss = nn.BCEWithLogitsLoss()

        # Neural Network Layers
        self.encoder2interaction_fc = nn.Linear(self.feature_dim, self.global_embed_size).to(device)
        self.encoder2interaction_highway = Highway(self.global_embed_size, self.highway_num_layer).to(device)
        self.pred_nn = nn.Linear(self.global_embed_size, 1)

        self.device = device
        self = self.to(device)

    def feed_lst_of_module(self, input_feature, lst_of_module):
        """
        Passes input through a list of modules with activation function.
        """
        x = input_feature
        for single_module in lst_of_module:
            x = self.f(single_module(x))
        return x
    
    def forward_enrollment_lst(self, enrollment_lst):
        """
        Processes a list of enrollment numbers to generate embeddings.
        """
        # Convert enrollment list to a tensor
        enrollment_tensor = torch.tensor(enrollment_lst, dtype=torch.float32, device=self.device).view(-1, 1)

        # Apply a linear transformation to project the enrollment numbers into the same embedding space
        # Define an embedding layer or a fully connected layer for enrollment
        if not hasattr(self, 'enrollment_fc'):
            self.enrollment_fc = nn.Linear(1, self.global_embed_size).to(self.device)

        # Pass through the embedding layer
        enrollment_embed = self.enrollment_fc(enrollment_tensor)

        return enrollment_embed

    def forward_get_three_encoders(self, smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst):
        """
        Processes molecule, disease, and protocol inputs to generate embeddings.
        """
        molecule_embed = self.molecule_encoder.forward_smiles_lst_lst(smiles_lst2)
        icd_embed = self.disease_encoder.forward_code_lst3(icdcode_lst3)
        protocol_embed = self.protocol_encoder.forward(criteria_lst)
        enrollment_embed = self.forward_enrollment_lst(enrollment_lst)
        #enrollment_embed = torch.cat([molecule_embed, icd_embed, protocol_embed, enrollment_tensor], dim=1)

        #print(f"molecule_embed shape: {molecule_embed.shape}")
        #print(f"icd_embed shape: {icd_embed.shape}")
        #print(f"protocol_embed shape: {protocol_embed.shape}")
        #print(f"enrollment_embed shape: {enrollment_embed.shape}")

        return molecule_embed, icd_embed, protocol_embed,enrollment_embed

    def forward_encoder_2_interaction(self, molecule_embed, icd_embed, protocol_embed, enrollment_embed):
        """
        Combines embeddings with enrollment to produce interaction embedding.
        """
        #enrollment_tensor = torch.tensor(enrollment_lst, dtype=torch.float).view(-1, 1).to(self.device)
        encoder_embedding = torch.cat([molecule_embed, icd_embed, protocol_embed, enrollment_embed], dim=1)
        
        h = self.encoder2interaction_fc(encoder_embedding)
        h = self.f(h)
        h = self.encoder2interaction_highway(h)
        interaction_embedding = self.f(h)
        #print(f"encoder_embedding shape: {encoder_embedding.shape}")  # Should be [batch_size, 200]
        #print(f"Expected feature_dim: {self.feature_dim}")  # Should be 200
        return interaction_embedding

    def forward(self, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst):
        """
        Forward pass of the Interaction model.
        """
        molecule_embed, icd_embed, protocol_embed,enrollment_embed = self.forward_get_three_encoders(smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst)
        interaction_embedding = self.forward_encoder_2_interaction(molecule_embed, icd_embed, protocol_embed, enrollment_embed)
        output = self.pred_nn(interaction_embedding)
        return output

    def evaluation(self, predict_all, label_all, threshold=0.5):
        """
        Evaluates model performance using various metrics.
        """
        auc_score = roc_auc_score(label_all, predict_all)

        label_all = [int(i) for i in label_all]
        predict_all = [0 if x < threshold else 1 for x in predict_all]
        f1score = f1_score(label_all, predict_all)
        prauc_score = average_precision_score(label_all, predict_all)
        precision = precision_score(label_all, predict_all)
        recall = recall_score(label_all, predict_all)
        accuracy = accuracy_score(label_all, predict_all)
        predict_1_ratio = sum(predict_all) / len(predict_all)
        label_1_ratio = sum(label_all) / len(label_all)

        return auc_score, f1score, prauc_score, precision, recall, accuracy, predict_1_ratio, label_1_ratio

    def testloader_to_lst(self, dataloader):
        """
        Extracts data from the dataloader into lists.
        """
        nctid_lst, label_lst, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst = [], [], [], [], [], []
        for nctid, label, smiles, icdcode, criteria, enrollment in dataloader:
            nctid_lst.extend(nctid)
            label_lst.extend([i.item() for i in label])
            smiles_lst2.extend(smiles)
            icdcode_lst3.extend(icdcode)
            criteria_lst.extend(criteria)
            enrollment_lst.extend(enrollment)
        length = len(nctid_lst)
        assert length == len(smiles_lst2) and length == len(icdcode_lst3) == len(enrollment_lst), "Data misalignment!"
        return nctid_lst, label_lst, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst, length

    def generate_predict(self, dataloader):
        """
        Generates predictions for a dataloader.
        """
        whole_loss = 0
        label_all, predict_all, nctid_all = [], [], []
        for nctid_lst, label_vec, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst in dataloader:
            nctid_all.extend(nctid_lst)
            label_vec = label_vec.to(self.device)
            output = self.forward(smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst).view(-1)
            loss = self.loss(output, label_vec.float())
            whole_loss += loss.item()
            predict_all.extend([i.item() for i in torch.sigmoid(output)])
            label_all.extend([i.item() for i in label_vec])

        return whole_loss, predict_all, label_all, nctid_all

    def test(self, dataloader, return_loss=True, validloader=None):
        """
        Tests the model on a dataloader.
        """
        self.eval()
        best_threshold = 0.5
        whole_loss, predict_all, label_all, nctid_all = self.generate_predict(dataloader)
        self.train()
        if return_loss:
            return whole_loss
        else:
            print_num = 5
            auc_score, f1score, prauc_score, precision, recall, accuracy, \
            predict_1_ratio, label_1_ratio = self.evaluation(predict_all, label_all, threshold=best_threshold)
            print(
                "ROC AUC: " + str(auc_score)[:print_num] + "\nF1: " + str(f1score)[:print_num] +
                "\nPR-AUC: " + str(prauc_score)[:print_num] +
                "\nPrecision: " + str(precision)[:print_num] +
                "\nRecall: " + str(recall)[:print_num] + "\nAccuracy: " + str(accuracy)[:print_num] +
                "\nPredict 1 ratio: " + str(predict_1_ratio)[:print_num] +
                "\nLabel 1 ratio: " + str(label_1_ratio)[:print_num]
            )
            return auc_score, f1score, prauc_score, precision, recall, accuracy, predict_1_ratio, label_1_ratio

    def learn(self, train_loader, valid_loader, test_loader):
        """
        Trains the model and evaluates on validation and test sets.
        """
        opt = torch.optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        train_loss_record = []
        valid_loss = self.test(valid_loader, return_loss=True)
        valid_loss_record = [valid_loss]
        best_valid_loss = valid_loss
        best_model = deepcopy(self)

        for ep in tqdm(range(self.epoch)):
            for nctid_lst, label_vec, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst in train_loader:
                label_vec = label_vec.to(self.device)
                output = self.forward(smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst).view(-1)
                loss = self.loss(output, label_vec.float())
                train_loss_record.append(loss.item())
                opt.zero_grad()
                loss.backward()
                opt.step()
            valid_loss = self.test(valid_loader, return_loss=True)
            valid_loss_record.append(valid_loss)
            if valid_loss < best_valid_loss:
                best_valid_loss = valid_loss
                best_model = deepcopy(self)

        #self.plot_learning_curve(train_loss_record, valid_loss_record)
        self.load_state_dict(best_model.state_dict())
        auc_score, f1score, prauc_score, precision, recall, accuracy, predict_1_ratio, label_1_ratio = \
            self.test(test_loader, return_loss=False, validloader=valid_loader)

    def select_threshold_for_binary(self, validloader):
        """
        Selects the optimal threshold for binary classification based on F1-score.
        """
        _, prediction, label_all, _ = self.generate_predict(validloader)
        best_f1 = 0
        best_threshold = 0.5  # Default threshold
        for threshold in prediction:
            predict_all = [1 if x >= threshold else 0 for x in prediction]
            f1score = f1_score(label_all, predict_all)
            if f1score > best_f1:
                best_f1 = f1score
                best_threshold = threshold
        return best_threshold


"""
Step 8
La classe HINT_nograph è una versione del modello HINT che non utilizza strutture basate su grafi, ma organizza i dati e i processi in una sequenza lineare 
attraverso strati di trasformazione, con l'obiettivo di prevedere un risultato clinico.
"""
class HINT_nograph(Interaction):
	def __init__(self, molecule_encoder, disease_encoder, protocol_encoder,device, 
					global_embed_size, 
					highway_num_layer,
					prefix_name, 
					epoch = 5, #20
					lr = 3e-4, 
					weight_decay = 0, ):
		super(HINT_nograph, self).__init__(molecule_encoder = molecule_encoder, 
								   disease_encoder = disease_encoder, 
								   protocol_encoder = protocol_encoder,
								   device = device,  
								   global_embed_size = global_embed_size, 
								   prefix_name = prefix_name, 
								   highway_num_layer = highway_num_layer,
								   epoch = epoch,
								   lr = lr, 
								   weight_decay = weight_decay, 
								   ) 
		self.save_name = prefix_name + '_HINT_nograph'

		#### risk of disease ->  Trasformano gli embedding delle malattie per calcolare il "rischio di malattia"
		self.risk_disease_fc = nn.Linear(self.disease_encoder.embedding_size, self.global_embed_size)
		self.risk_disease_higway = Highway(self.global_embed_size, self.highway_num_layer)

		#### augment interaction -> Combinano l'embedding dell'interazione con il rischio di malattia, creando un embedding più ricco.
		self.augment_interaction_fc = nn.Linear(self.global_embed_size*2, self.global_embed_size)
		self.augment_interaction_highway = Highway(self.global_embed_size, self.highway_num_layer)

		#### ADMET -> Modella le proprietà farmacologiche delle molecole
		self.admet_model = []
		for i in range(5):
			admet_fc = nn.Linear(self.molecule_encoder.embedding_size, self.global_embed_size).to(device)
			admet_highway = Highway(self.global_embed_size, self.highway_num_layer).to(device)
			self.admet_model.append(nn.ModuleList([admet_fc, admet_highway])) 
		self.admet_model = nn.ModuleList(self.admet_model)

		#### PK 
		self.pk_fc = nn.Linear(self.global_embed_size*5, self.global_embed_size)
		self.pk_highway = Highway(self.global_embed_size, self.highway_num_layer)

		#### trial node 
		self.trial_fc = nn.Linear(self.global_embed_size*2, self.global_embed_size)
		self.trial_highway = Highway(self.global_embed_size, self.highway_num_layer)

		## self.pred_nn = nn.Linear(self.global_embed_size, 1)

		self.device = device 
		self = self.to(device)

	"""
	Esegue il flusso di elaborazione dei dati e calcola l'output del modello. 
	"""

	def forward(self, smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst, if_gnn = False):
		### encoder for molecule, disease and protocol ->  generare gli embedding iniziali 
		molecule_embed, icd_embed, protocol_embed,enrollment_embed = self.forward_get_three_encoders(smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst)

		### interaction ->  embedding iniziali vengono combinati per calcolare l'embedding di interazione
		interaction_embedding = self.forward_encoder_2_interaction(molecule_embed, icd_embed, protocol_embed,enrollment_embed)

		### risk of disease -> viene trasformato in un embedding di "rischio di malattia" utilizzando un fully connected e una rete Highway.
		risk_of_disease_embedding = self.feed_lst_of_module(input_feature = icd_embed, 
															lst_of_module = [self.risk_disease_fc, self.risk_disease_higway])
		
		### augment interaction -> Combina l'embedding di interazione e il rischio di malattia in un embedding arricchito   
		augment_interaction_input = torch.cat([interaction_embedding, risk_of_disease_embedding], 1)
		augment_interaction_embedding = self.feed_lst_of_module(input_feature = augment_interaction_input, 
																lst_of_module = [self.augment_interaction_fc, self.augment_interaction_highway])
		
		### admet -> Calcola embedding separati per ciascuna dimensione di ADMET 
		admet_embedding_lst = []
		for idx in range(5):
			admet_embedding = self.feed_lst_of_module(input_feature = molecule_embed, 
													  lst_of_module = self.admet_model[idx])
			admet_embedding_lst.append(admet_embedding)

		### pk -> Combina gli embedding ADMET in un embedding farmacocinetico
		pk_input = torch.cat(admet_embedding_lst, 1)
		pk_embedding = self.feed_lst_of_module(input_feature = pk_input, 
											   lst_of_module = [self.pk_fc, self.pk_highway])
		
		### trial -> Combina l'embedding farmacocinetico e l'embedding arricchito in un embedding finale
		trial_input = torch.cat([pk_embedding, augment_interaction_embedding], 1)
		trial_embedding = self.feed_lst_of_module(input_feature = trial_input, 
												  lst_of_module = [self.trial_fc, self.trial_highway])
		
		#output of the model -> Passa l'embedding finale attraverso uno strato fully connected (self.pred_nn) 
		# per produrre l'output binario (probabilità di successo del trial).
		output = self.pred_nn(trial_embedding)


		if if_gnn == False:
			return output 
		else:
			embedding_lst = [molecule_embed, icd_embed, protocol_embed, interaction_embedding, risk_of_disease_embedding, \
							 augment_interaction_embedding,enrollment_embed] + admet_embedding_lst + [pk_embedding, trial_embedding]
			return embedding_lst


"""
Step 9
Nel modello HINTModel, gli strati GCN e GAT vengono combinati per creare un modello completo. L'implementazione collega gli 
strati di attenzione e convoluzione al flusso dei dati. 

La classe HINTModel estende la classe HINT_nograph e integra sia Graph Convolutional Networks (GCN) sia Graph Attention Networks (GAT) per creare un modello completo e 
interpretabile. Di seguito trovi una spiegazione passo per passo della classe, seguita da una sua versione semplificata per studiarne più facilmente l’interpretabilità.

"""

class HINTModel(HINT_nograph):

    def __init__(self, molecule_encoder, disease_encoder, protocol_encoder,
                 device, 
                 global_embed_size, 
                 highway_num_layer,
                 prefix_name, 
                 gnn_hidden_size, 
                 epoch=20,
                 lr=3e-4, 
                 weight_decay=0):
        super().__init__(molecule_encoder=molecule_encoder, 
                         disease_encoder=disease_encoder, 
                         protocol_encoder=protocol_encoder,
                         device=device, 
                         prefix_name=prefix_name, 
                         global_embed_size=global_embed_size, 
                         highway_num_layer=highway_num_layer,
                         epoch=epoch,
                         lr=lr, 
                         weight_decay=weight_decay)
        self.save_name = prefix_name
        self.gnn_hidden_size = gnn_hidden_size

        # GNN
        self.adj = self.generate_adj()          
        self.gnn = GCN(
            nfeat=self.global_embed_size,
            nhid=self.gnn_hidden_size,
            nclass=1,
            dropout=0.6,
            init='uniform'
        )
        # GNN's attention
        self.node_size = self.adj.shape[0]

        self.graph_attention_model_mat = nn.ModuleList(
            [nn.ModuleList([self.gnn_attention() if self.adj[i, j] == 1 else None for j in range(self.node_size)]) for i in range(self.node_size)]
        )

        self.device = device
        self = self.to(device)

    def generate_adj(self):        								
        lst = ["molecule", "disease", "enrollment", "criteria", 'INTERACTION', 'risk_disease', 
               'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final"]
        edge_lst = [("disease", "molecule"), ("disease", "criteria"), ("molecule", "criteria"), 
                    ("disease", "INTERACTION"), ("molecule", "INTERACTION"), ("criteria", "INTERACTION"), 
                    ("disease", "risk_disease"), ('risk_disease', 'augment_interaction'), ('INTERACTION', 'augment_interaction'),
                    ("molecule", "A"), ("molecule", "D"), ("molecule", "M"), ("molecule", "E"), ("molecule", "T"),
                    ('A', 'PK'), ('D', 'PK'), ('M', 'PK'), ('E', 'PK'), ('T', 'PK'), 
                    ('augment_interaction', 'final'), ('PK', 'final'), ('enrollment','criteria'), ('enrollment','INTERACTION')]
        adj = torch.zeros(len(lst), len(lst))
        adj = torch.eye(len(lst)) * len(lst)
        num2str = {k: v for k, v in enumerate(lst)}
        str2num = {v: k for k, v in enumerate(lst)}
        for i, j in edge_lst:
            n1, n2 = str2num[i], str2num[j]
            adj[n1, n2] = 1
            adj[n2, n1] = 1
        return adj.to(self.device)

    def generate_attention_matrx(self, node_feature_mat):
        #print(f"self.node_size: {self.node_size}")
        #print(f"node_feature_mat.shape: {node_feature_mat.shape}")
        #print(f"self.adj.shape: {self.adj.shape}")
        attention_mat = torch.zeros(self.node_size, self.node_size).to(self.device)
        for i in range(self.node_size):
            for j in range(self.node_size):
                if self.adj[i, j] != 1:
                    continue 
                feature = torch.cat([node_feature_mat[i].view(1, -1), node_feature_mat[j].view(1, -1)], 1)
                attention_model = self.graph_attention_model_mat[i][j]
                attention_mat[i, j] = torch.sigmoid(self.feed_lst_of_module(input_feature=feature, lst_of_module=attention_model))
        return attention_mat 

    def gnn_attention(self):
        highway_nn = Highway(size=self.global_embed_size * 2, num_layers=self.highway_num_layer).to(self.device)
        highway_fc = nn.Linear(self.global_embed_size * 2, 1).to(self.device)
        return nn.ModuleList([highway_nn, highway_fc])

    def forward(self, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst, return_attention_matrix=False):
        # Get embeddings from the parent class
        embedding_lst = HINT_nograph.forward(self, smiles_lst2, icdcode_lst3, criteria_lst, enrollment_lst, if_gnn=True)
        
        batch_size = embedding_lst[0].shape[0]
        output_lst = []
        if return_attention_matrix:
            attention_mat_lst = []

        for i in range(batch_size):
            # Include enrollment in node features
            node_feature_lst = [embedding[i].view(1, -1) for embedding in embedding_lst]
            node_feature_mat = torch.cat(node_feature_lst, 0)
            attention_mat = self.generate_attention_matrx(node_feature_mat)

            output = self.gnn(node_feature_mat, self.adj * attention_mat)
            output = output[-1].view(1, -1)
            output_lst.append(output)

            if return_attention_matrix:
                attention_mat_lst.append(attention_mat)

        output_mat = torch.cat(output_lst, 0)

        if not return_attention_matrix:
            return output_mat
        else:
            return output_mat, attention_mat_lst

        
    def compute_aggregated_attention(self, complete_dataloader):
        """
        Compute aggregated attention matrices batch-by-batch and average them.

        Parameters:
        - dataloader: DataLoader providing batches of input data.

        Returns:
        - aggregated_attention: Aggregated attention matrix across all batches.
        """
        self.eval()  # Set the model to evaluation mode
        all_attention_matrices = []  # To store attention matrices from all batches

        with torch.no_grad():
            for nctid_lst, status_lst, why_stop_lst, label_vec, phase_lst, \
                diseases_lst, icdcode_lst3, drugs_lst, smiles_lst2, criteria_lst,enrollment_lst in complete_dataloader:
                output, attention_mat_lst = self.forward(smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst, return_attention_matrix=True)
                    
                # Stack the attention matrices in the batch
                batch_attention = torch.stack(attention_mat_lst, dim=0)  # Shape: (batch_size, num_nodes, num_nodes)
                all_attention_matrices.append(batch_attention)

        # Concatenate all batches and compute mean
        all_attention_matrices = torch.cat(all_attention_matrices, dim=0)  # Shape: (total_samples, num_nodes, num_nodes)
        aggregated_attention = all_attention_matrices.mean(dim=0)  # Shape: (num_nodes, num_nodes)

        return aggregated_attention

    
    def plot_aggregated_heatmap(self, complete_dataloader, title="Aggregated Attention Heatmap"):
        """
        Plot the aggregated attention heatmap using data from the complete_dataloader.

        Parameters:
        - complete_dataloader: DataLoader providing batches of input data.
        - title: Title of the heatmap.
        """
        node_labels = ["molecule", "disease", "criteria", 'INTERACTION', 'risk_disease',
                    'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final","enrollment"]

        # Compute the aggregated attention matrix
        aggregated_attention = self.compute_aggregated_attention(complete_dataloader)

        # Save heatmap
        save_name = 'heatmap_result/aggregated_attention_heatmap.png'
        plt.figure(figsize=(20, 16))
        heatmap = plt.imshow(aggregated_attention.cpu().numpy(), cmap="viridis", interpolation="nearest")
        plt.colorbar(label="Attention Weight")
        plt.xticks(ticks=np.arange(len(node_labels)), labels=node_labels, rotation=90)
        plt.yticks(ticks=np.arange(len(node_labels)), labels=node_labels)
        plt.title(title)

        # Annotate heatmap with values
        for i in range(aggregated_attention.shape[0]):
            for j in range(aggregated_attention.shape[1]):
                value = aggregated_attention[i, j].item()  # Extract value from tensor
                plt.text(j, i, f"{value:.2f}", ha="center", va="center", color="white" if value > 0.5 else "black")

        plt.savefig(save_name)
        plt.close()
        print(f"Saved heatmap: {save_name}")



    def plot_aggregated_graph(self, complete_dataloader, title="Aggregated Attention Graph"):
        """
        Plot the aggregated attention graph using data from the complete_dataloader.

        Parameters:
        - complete_dataloader: DataLoader providing batches of input data.
        - title: Title of the graph.
        """
        def replace_strange_symbol(text):
            for i in "[]'\n/":
                text = text.replace(i, '_')
            return text

        if not os.path.exists("graph_result"):
            os.makedirs("graph_result")

        node_labels = ["molecule", "disease", "criteria", 'INTERACTION', 'risk_disease',
                    'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final"]

        # Compute the aggregated attention matrix
        aggregated_attention = self.compute_aggregated_attention(complete_dataloader)

        # Create a NetworkX graph
        G = nx.Graph()
        num_nodes = len(node_labels)

        # Add nodes with labels
        for i in range(num_nodes):
            G.add_node(i, label=node_labels[i])

        # Add edges based on attention matrix without adjacency filtering
        for i in range(num_nodes):
            for j in range(num_nodes):
                G.add_edge(i, j, weight=aggregated_attention[i, j].item())

        # Node positions with increased edge lengths
        pos = nx.spring_layout(G, seed=42, k=1.5)

        # Create the plot
        fig, ax = plt.subplots(figsize=(18, 18))
        edge_labels = nx.get_edge_attributes(G, "weight")
        nx.draw_networkx_nodes(G, pos, node_size=800, node_color="skyblue", edgecolors="black", linewidths=2.5, ax=ax)
        nx.draw_networkx_edges(
            G, pos,
            width=[max(0.1, 3 * edge_labels[k]) for k in G.edges],  # Minimum width for low-weight edges
            alpha=0.7,
            edge_color="black",
            ax=ax
        )
        nx.draw_networkx_labels(G, pos, labels={i: node_labels[i] for i in range(num_nodes)}, font_size=12, font_color="black", ax=ax)
        nx.draw_networkx_edge_labels(
            G, pos,
            edge_labels={k: f"{v:.2f}" for k, v in edge_labels.items()},  # Format weights to 2 decimal places
            font_size=10,
            font_color="red",
            ax=ax
        )

        # Add colorbar explicitly tied to the current axis
        sm = plt.cm.ScalarMappable(cmap=plt.cm.Blues, norm=plt.Normalize(vmin=min(edge_labels.values()), vmax=max(edge_labels.values())))
        sm._A = []
        fig.colorbar(sm, ax=ax, label="Attention Weight")

        # Save the graph
        save_name = f"graph_result/aggregated_attention_graph_{replace_strange_symbol(title)}.png"
        plt.title(title, fontsize=16)
        plt.savefig(save_name, dpi=300, bbox_inches="tight")
        plt.close()
        print(f"Saved graph: {save_name}")


        """

            #def plot_node_importance(attention_matrix, node_labels, title="Node Importance"):
                #node_labels = ["molecule", "disease", "criteria", 'INTERACTION', 'risk_disease',
                                'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final"]

                # Compute importance as sum of attention weights per node
                #importance = attention_matrix.sum(dim=1).cpu().numpy()

                # Create a DataFrame for visualization
                #df = pd.DataFrame({"Node": node_labels, "Importance": importance})
                df = df.sort_values(by="Importance", ascending=False)

                # Plot bar chart
                plt.figure(figsize=(12, 6))
                sns.barplot(x="Importance", y="Node", data=df, palette="viridis")
                plt.title(title)
                plt.xlabel("Aggregate Attention Weight")
                plt.ylabel("Node")
                plt.show()

        """
        
    def visualize_attention_graph(self, adj, attention_matrix, node_labels, save_name=None):
        node_labels = ["molecule", "disease", "criteria", 'INTERACTION', 'risk_disease',
                           'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final"]
        """
        Visualize the attention graph using NetworkX and Matplotlib.
        """
        # Convert adjacency matrix to NetworkX graph
        G = nx.from_numpy_array(adj.cpu().numpy())
        pos = nx.spring_layout(G, seed=42)

        # Node sizes and colors
        node_sizes = [200 + 1000 * attention_matrix[i, i].item() for i in range(len(node_labels))]
        node_colors = ["skyblue" if "molecule" in lbl else "lightgreen" for lbl in node_labels]
        edge_weights = [
            attention_matrix[u, v].item() if adj[u, v] == 1 else 0
            for u, v in G.edges
        ]

        # Draw nodes and labels
        nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=node_sizes)
        nx.draw_networkx_labels(G, pos, labels={i: lbl for i, lbl in enumerate(node_labels)})
        nx.draw_networkx_edges(
            G,
            pos,
            edge_color=edge_weights,
            edge_cmap=plt.cm.Blues,
            width=2,
        )

        # Add colorbar for edge weights
        sm = plt.cm.ScalarMappable(cmap=plt.cm.Blues, norm=plt.Normalize(vmin=min(edge_weights), vmax=max(edge_weights)))
        sm._A = []
        plt.colorbar(sm)

        plt.axis("off")
        plt.title("Attention Graph Visualization")

        # Save or show the graph
        if save_name:
            plt.savefig(save_name)
            plt.close()
        else:
            plt.show()
            plt.close()

    def interpret(self, complete_dataloader):
        def replace_strange_symbol(text):
            for i in "[]'\n/":
                text = text.replace(i, '_')
            return text

        if not os.path.exists("interpret_result"):
            os.makedirs("interpret_result")

        for nctid_lst, status_lst, why_stop_lst, label_vec, phase_lst, \
            diseases_lst, icdcode_lst3, drugs_lst, smiles_lst2, criteria_lst,enrollment_lst in complete_dataloader: 
            output, attention_mat_lst = self.forward(smiles_lst2, icdcode_lst3, criteria_lst,enrollment_lst, return_attention_matrix=True)
            output = output.view(-1)
            batch_size = len(nctid_lst)
            node_labels = ["molecule", "disease", "criteria", 'INTERACTION', 'risk_disease',
                           'augment_interaction', 'A', 'D', 'M', 'E', 'T', 'PK', "final"]
            for i in range(batch_size):
                try:
                    if i >= len(nctid_lst) or i >= len(status_lst) or i >= len(label_vec) or \
                       i >= len(phase_lst) or i >= len(diseases_lst) or i >= len(drugs_lst):
                        print(f"Skipping index {i}: index out of range")
                        continue

                    name = '__'.join([str(nctid_lst[i]), str(status_lst[i]), why_stop_lst[i], 
                                      str(label_vec[i]), str(torch.sigmoid(output[i]).item())[:5], 
                                      phase_lst[i], diseases_lst[i], drugs_lst[i]])
                    if len(name) > 150:
                        name = name[:250]
                    name = replace_strange_symbol(name)
                    name = name.replace('__', '_').replace('  ', ' ')
                    save_name = 'interpret_result/' + name + '.png'
                    print(f"Saving image: {save_name}")
                    self.visualize_attention_graph(self.adj, attention_mat_lst[i], node_labels, save_name=save_name)
                except Exception as e:
                    print(f"Error processing index {i}: {e}")
                    continue

    def init_pretrain(self, admet_model):
        self.molecule_encoder = admet_model.molecule_encoder
