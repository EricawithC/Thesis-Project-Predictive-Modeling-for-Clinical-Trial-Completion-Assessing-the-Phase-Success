The model_experiment_enrollment script works with .phy files originally created by Fu, incorporating Captum’s library to analyze GCN and GAT models. The attention matrix has been modified to generate a heatmap that visualizes how the model distributes attention across different features during execution.

The learn_phases_enrollment.py script runs the model, applying evaluation and verification processes to assess its performance. It ensures proper data preprocessing, model training, and validation, making it an essential part of the workflow.

The Jupyter Notebook files are dedicated to conducting feature importance analysis using Captum’s library. They apply methods like Integrated Gradients and Saliency Maps to examine the impact of individual features on model predictions.